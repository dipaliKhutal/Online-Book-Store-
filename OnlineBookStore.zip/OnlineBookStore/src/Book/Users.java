package Book;

import java.util.Scanner;

public class Users {
	// Creating objects of Scanner and students class
    
	Scanner input = new Scanner(System.in);
    User theUsers[] = new User[50];
	
 
    public static int count = 0;
 
    // Method 1
    // To add books
    public void addUser(User s)
    {
        for (int i = 0; i < count; i++) {
 
            if ((s.regNum).equalsIgnoreCase(
                    (String) theUsers[i].regNum)) {
 
                // Print statement
                System.out.println(
                    "user of Reg Num " + s.regNum
                    + " is Already Registered.");
 
                return;
            }
        }
 
        if (count <= 50) {
            theUsers[count] = s;
            count++;
        }
    }
 
    // Method 2
    // Displaying all students
    public void showAllUsers()
    {
        // Printing user name and
        // corresponding registered number
        System.out.println("User Name\t\tReg Number");
        for (int i = 0; i < count; i++) {
 
            System.out.println(theUsers[i].UserName
                               + "\t\t"
                               + theUsers[i].regNum);
        }
    }
 
    // Method 3
    // To check the Student
    public int isUser()
    {
        // Display message only
        System.out.println("Enter Reg Number:");
 
        String regNum = input.nextLine();
 
        for (int i = 0; i < count; i++) {
 
            if (theUsers[i].regNum.equalsIgnoreCase(
                    regNum)) {
                return i;
            }
        }
 
        // Print statements
        System.out.println("User is not Registered.");
        System.out.println("Get Registered First.");
 
        return -1;
    }
 
    // Method 4
    // To remove the book
    public void checkOutbook(Books Book)
    {
        int UserIndex = this.isUser();
 
        if (UserIndex != -1) {
            System.out.println("checking out");
 
            Book.showAllBooks();
            Book b = Book.checkOutBook();
 
            System.out.println("checking out");
            if (b != null) {
 
                if (theUsers[UserIndex].booksCount
                    <= 3) {
 
                    System.out.println("adding book");
                    theUsers[UserIndex].borrowedBooks
                        [theUsers[UserIndex]
                             .booksCount]
                        = b;
                    theUsers[UserIndex].booksCount++;
 
                    return;
                }
                else {
 
                    System.out.println(
                        "Student Can not Borrow more than 3 Books.");
                    return;
                }
            }
            System.out.println("Book is not Available.");
        }
    }
 
    // Method 5
    // To add the book
    public void checkInbook(Books Book)
    {
        int UserIndex = this.isUser();
        if (UserIndex != -1) {
 
            // Printing credentials corresponding to user
            System.out.println(
                "S.No\t\t\tBook Name\t\t\tAuthor Name");
 
            User s = theUsers[UserIndex];
 
            for (int i = 0; i < s.booksCount; i++) {
 
                System.out.println(
                    s.borrowedBooks[i].sNo + "\t\t\t"
                    + s.borrowedBooks[i].bookName + "\t\t\t"
                    + s.borrowedBooks[i].authorName);
            }
 
            // Display message only
            System.out.println(
                "Enter Serial Number of Book to be Checked In:");
 
            int sNo = input.nextInt();
 
            for (int i = 0; i < s.booksCount; i++) {
                if (sNo == s.borrowedBooks[i].sNo) {
                    Book.checkInBook(s.borrowedBooks[i]);
                    s.borrowedBooks[i] = null;
 
                    return;
                }
            }
 
            System.out.println("Book of Serial No " + sNo
                               + "not Found");
        }
    }
}

